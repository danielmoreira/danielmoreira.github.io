# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2020
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Face Recognition
# 02. Module to enhance face samples, aiming at further feature extraction.
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/),
# and SciPy (https://www.scipy.org/).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python==3.4.2.17";
# "pip3 install scipy".

import cv2
import math
import numpy
import scipy.ndimage

# TODO
# Descriptions will be added soon.
FRAME_WIDTH = 640
FACE_SIZE = 256
VJ_FACE_DETECTOR = cv2.CascadeClassifier('data/haarcascade_frontalface_default.xml')
VJ_EYES_DETECTOR = cv2.CascadeClassifier('data/haarcascade_eye.xml')


# Rotates a given <image> CCW obeying the given <rad_angle>.
# Image content is them cropped to avoid empty borders, bounded by the largest possible inscribed square.
# Return the obtained rotated and cropped image.
def __rotate_and_crop(image, rad_angle):
    h, w = image.shape

    degree_angle = 360.0 - (180.0 * rad_angle / numpy.pi)
    rotated = scipy.ndimage.rotate(image, degree_angle, reshape=False)

    crop_size = int(round(h / numpy.sqrt(2)))
    crop_start = int((h - crop_size) / 2.0)

    rotated = rotated[crop_start: crop_start + crop_size, crop_start: crop_start + crop_size]
    return rotated


# TODO
# Description will be added soon.
def _01_preprocess(frame, output_width, view=False):
    # makes the frame grayscale, if it is still colored
    if len(frame.shape) > 2 and frame.shape[2] > 1:  # more than one channel?
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # resizes the frame to present a width of <output_width> pixels, keeping original aspect ratio
    aspect_ratio = float(frame.shape[1]) / frame.shape[0]
    height = int(round(output_width / aspect_ratio))
    frame = cv2.resize(frame, (output_width, height))

    # shows the obtained frame, if it is the case
    if view:
        cv2.imshow('Preprocessing, press any key.', frame)
        cv2.waitKey(0)

    print('[INFO] Preprocessed frame.')
    return frame


# TODO
# Description will be added soon.
def _02_detect_face(grayscale_frame, view=False):
    # detects faces on the given frame with Viola-Jones detector
    face_boxes = VJ_FACE_DETECTOR.detectMultiScale(grayscale_frame)

    # if there are no faces, returns None
    if len(face_boxes) == 0:
        return None

    # else...
    # takes only the last face among the detected ones
    x, y, w, h = face_boxes[0]  # TODO detecting more faces can be added here
    face = grayscale_frame[y:y + h, x:x + w]

    # show the obtained face, if it is the case
    if view:
        cv2.imshow('Detected face, press any key.', face)
        cv2.waitKey(0)

    print('[INFO] Detected one face.')
    return face


# TODO
# Description will be added soon.
def _03_align_face(face, view=False):
    # detects eyes on the given face with Viola-Jones detector
    eye_boxes = VJ_EYES_DETECTOR.detectMultiScale(face)

    # if no eyes were detected, returns None
    if len(eye_boxes) != 2:
        return None

    # else...
    # rotates the face in a way that eyes are aligned in the horizontal position
    x1, y1, w1, h1, = eye_boxes[0]  # eye 1
    x2, y2, w2, h2, = eye_boxes[1]  # eye 2

    if x1 < x2:
        xc1 = x1 + w1 / 2.0  # right eye, mirrored on the left
        yc1 = y1 + h1 / 2.0

        xc2 = x2 + w2 / 2.0  # left eye, mirrored on the right
        yc2 = y2 + h2 / 2.0

    else:
        xc2 = x1 + w1 / 2.0  # left eye, mirrored on the right
        yc2 = y1 + h1 / 2.0

        xc1 = x2 + w2 / 2.0  # right eye, mirrored on the right
        yc1 = y2 + h2 / 2.0

    # angle between eyes
    angle = math.atan2(yc2 - yc1, xc2 - xc1)

    # face rotation
    face = __rotate_and_crop(face, -angle)

    # resizes the face after rotation
    face = cv2.resize(face, (FACE_SIZE, FACE_SIZE))

    # show the aligned face, if it is the case
    if view:
        cv2.imshow('Aligned face, press any key.', face)
        cv2.waitKey(0)

    print('[INFO] Aligned the face.')
    return face


# TODO
# Description will be added soon.
def _04_fix_illumination(face, view=False):
    face = cv2.equalizeHist(face, face)

    if view:
        cv2.imshow('[INFO] Equalized face, press any key.', face)
        cv2.waitKey(0)

    return face


def enhance(frame, view=False):
    # pre-processes the given frame
    pp_frame = _01_preprocess(frame, FRAME_WIDTH, view=view)

    # detects a face in the given frame
    face = _02_detect_face(pp_frame, view=view)

    # aligns the obtained face
    if face is not None:
        face = _03_align_face(face, view=view)

    # fixes the illumination of the obtained face
    if face is not None:
        face = _04_fix_illumination(face, view=view)

    return face
