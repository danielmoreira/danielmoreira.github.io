# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2020
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Face Recognition
# 01. Acquisition-module stub.
# Language: Python 3
# Needed libraries: OpenCV (https://opencv.org/)
# Quick install (with PyPI - https://pypi.org/):
# execute "pip3 install opencv-contrib-python==3.4.2.17" on command shell.

import cv2

# TODO
# Description will be added soon.
CAM_ID = 0
global CAM
CAM = None


# TODO
# Description will be added soon.
def acquire_from_camera(view=False):
    global CAM
    if CAM is None:
        CAM = cv2.VideoCapture(CAM_ID)

    _, frame = CAM.read()

    if view:
        cv2.imshow('press any key', frame)
        cv2.waitKey(0)

    return frame


# TODO
# Description will be added soon.
def acquire_from_file(file_path, view=False):
    # reads the image from the given file path
    # and returns it
    image = cv2.imread(file_path)

    # show the read image, if it is the case
    if view:
        cv2.imshow('Press any key.', image)
        cv2.waitKey(0)

    print('[INFO] Acquired image from file.')
    return image
