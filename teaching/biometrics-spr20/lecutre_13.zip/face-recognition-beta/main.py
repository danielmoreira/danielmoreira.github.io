# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2020
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Face Recognition
# TODO: Test script. Better description will be added soon.
# Language: Python 3

import cv2

import a_acquire
import b_enhance
import c_describe
import d_match

# Test script.
# TODO: Better description will be added soon.

# image file paths
image_file_path_1 = './data/random.jpg'
image_file_path_2 = './data/random_2.jpg'

# acquires the face images
frame1 = a_acquire.acquire_from_file(image_file_path_1, view=False)
frame2 = a_acquire.acquire_from_file(image_file_path_2, view=False)

# enhances the face images
face1 = b_enhance.enhance(frame1, view=True)
face2 = b_enhance.enhance(frame2, view=True)

# describes the given faces
description1 = c_describe.describe(face1, view=True)
description2 = c_describe.describe(face2, view=True)

# matches the given faces
dissimilarity12 = d_match.match(description1, description2)
print('Dissimilarity:', str(dissimilarity12) + '.')
