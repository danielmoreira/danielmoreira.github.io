# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2020
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Face Recognition
# 04. Module to match face descriptions.
# Language: Python 3
# Needed libraries: TODO.
# Quick install (with PyPI - https://pypi.org/): TODO.

import numpy


# TODO
# Description will be added soon.
def match(face_description_1, face_description_2):
    # computes and returns the dissimilarity between the face descriptions
    dissimilarity = numpy.linalg.norm(face_description_1 - face_description_2, ord=2)  # '2': l2, Euclidean distance
    return dissimilarity
