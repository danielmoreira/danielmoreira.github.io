# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2020
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Face Recognition
# It uses available webcam to capture faces.
# TODO: Test script. Better description will be added soon.
# Language: Python 3

import cv2

import a_acquire
import b_enhance
import c_describe
import d_match

# Test script.
# TODO: Better description will be added soon.

while True:
    # acquires the current camera frame
    frame1 = a_acquire.acquire_from_camera(view=True)

    # enhances the current frame, getting one face
    face1 = b_enhance.enhance(frame1, view=True)

    # if a face was processed, stops reading the camera
    if face1 is not None:
        break

while True:
    # acquires another camera frame
    frame2 = a_acquire.acquire_from_camera(view=True)

    # enhances the current frame, getting one face
    face2 = b_enhance.enhance(frame2, view=True)

    # if a face was processed, stops reading the camera
    if face2 is not None:
        break

# describes the obtained faces
description1 = c_describe.describe(face1, view=True)
description2 = c_describe.describe(face2, view=True)

# matches the obtained faces
dissimilarity12 = d_match.match(description1, description2)
print('Dissimilarity:', str(dissimilarity12) + '.')
