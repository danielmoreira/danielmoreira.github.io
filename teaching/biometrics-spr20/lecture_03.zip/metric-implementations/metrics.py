# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2020
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Simple implementation of biometric-related metrics.
# Language: Python 3
# Needed library: matplotlib (https://matplotlib.org/).
# Quick install (with PyPI - https://pypi.org/): execute "pip3 install matplotlib" on command shell


import math
import matplotlib.pyplot as plt


# Sums all the values in the given list, using pairwise summation to reduce round-off error.
def _pairwise_sum(values):
    if len(values) == 0:
        return float('inf')  # nothing to sum

    elif len(values) == 1:
        return values[0]  # one element, returns it

    elif len(values) == 2:
        return values[0] + values[1]  # two elements, returns their sum

    else:
        i = int(len(values) / 2)
        return _pairwise_sum(values[0:i]) + _pairwise_sum(values[i:len(values)])  # recursive call


# Computes the variance of the given values.
def _compute_var(values):
    if len(values) == 0:
        return float('inf')  # nothing to compute

    # mean of values
    mean = _pairwise_sum(values) / len(values)

    # deviations
    deviations = []
    for v in values:
        deviations.append((v - mean) ** 2.0)

    # variance
    var = _pairwise_sum(deviations) / len(deviations)
    return var


# Loads data from the file stored in the given file path.
def load_data(file_path):
    # output
    output = []

    # reads each line of the file, ignoring empty lines and the ones starting with '#'
    with open(file_path) as f:
        for line in f:
            content = line.strip().split(',')
            if len(content) > 0 and content[0][0] != '#':
                gt = int(content[0])
                score = float(content[1])

                output.append((gt, score))

    return output


# Computes FMR from the given observations, according to the given threshold
def compute_fmr(observations, threshold, is_similarity=True):
    impostor_count = 0
    false_match_count = 0

    for obs in observations:
        if obs[0] == 0:  # impostor line
            impostor_count = impostor_count + 1

            if is_similarity and obs[1] > threshold:
                false_match_count = false_match_count + 1

            elif not is_similarity and obs[1] < threshold:
                false_match_count = false_match_count + 1

    if impostor_count > 0:
        return float(false_match_count) / impostor_count
    else:
        return float('inf')


# Computes FNMR from the given observations, according to the given threshold
def compute_fnmr(observations, threshold, is_similarity=True):
    genuine_count = 0
    false_non_match_count = 0

    for obs in observations:
        if obs[0] == 1:  # genuine line
            genuine_count = genuine_count + 1

            if is_similarity and obs[1] < threshold:
                false_non_match_count = false_non_match_count + 1

            elif not is_similarity and obs[1] > threshold:
                false_non_match_count = false_non_match_count + 1

    if genuine_count > 0:
        return float(false_non_match_count) / genuine_count
    else:
        return float('inf')


# Computes FNMR and FMR at EER
def compute_fmr_fnmr_eer(observations, is_similarity=True):
    # computed FNMR and FMR at EER, and their difference, and EER threshold
    output_fnmr = float('inf')
    output_fmr = float('inf')
    fnmr_fmr_diff = float('inf')
    output_threshold = float('inf')

    # sorted list of scores
    scores = []
    for obs in observations:
        scores.append(obs[1])
    scores = sorted(scores)

    # for each score taken as threshold
    for threshold in scores:
        current_fnmr = compute_fnmr(observations, threshold, is_similarity)
        current_fmr = compute_fmr(observations, threshold, is_similarity)

        # cancels computation if any of the FNMR or FMR values are infinite (not possible to compute them)
        if current_fnmr == float('inf') or current_fmr == float('inf'):
            return float('inf'), float('inf'), float('inf')  # nothing to do here

        # updates the difference between FNMR and FMR, if it is the case
        current_diff = abs(current_fnmr - current_fmr)
        if current_diff <= fnmr_fmr_diff:
            output_fnmr = current_fnmr
            output_fmr = current_fmr
            fnmr_fmr_diff = current_diff
            output_threshold = threshold

        else:
            # difference will start to increase, nothing to do anymore
            break

    return output_fnmr, output_fmr, output_threshold


# Computes FMR x FNMR AUC.
def compute_fmr_fnmr_auc(observations, is_similarity=True):
    # sorted list of scores
    scores = []
    for obs in observations:
        scores.append(obs[1])
    scores = sorted(scores)

    # holds the computed FMR and FNMR values
    fmr = []
    fnmr = []

    # for each score taken as threshold
    for threshold in scores:
        current_fmr = compute_fmr(observations, threshold, is_similarity)
        current_fnmr = compute_fnmr(observations, threshold, is_similarity)

        # cancels computation if any of the FMR or FNMR values are infinite (not possible to compute them)
        if current_fnmr == float('inf') or current_fmr == float('inf'):
            return float('inf'), float('inf'), float('inf')  # nothing to do here

        # adds the computed values to the proper lists
        fmr.append(current_fmr)
        fnmr.append(current_fnmr)

    # computes the auc
    auc_parts = []
    for i in range(len(fmr) - 1):
        auc_parts.append(abs(fmr[i] - fmr[i + 1]) * (fnmr[i] + fnmr[i + 1]) / 2.0)
    auc = _pairwise_sum(auc_parts)

    return auc, fmr, fnmr


# Computes d-prime value.
def compute_d_prime(observations):
    # collects genuine and impostor scores
    genuine_scores = []
    impostor_scores = []

    for obs in observations:
        if obs[0] == 1:  # genuine line
            genuine_scores.append(obs[1])
        else:  # impostor line
            impostor_scores.append(obs[1])

    if len(genuine_scores) == 0 or len(impostor_scores) == 0:
        return float('inf')

    # computes mean values
    genuine_mean = _pairwise_sum(genuine_scores) / len(genuine_scores)
    impostor_mean = _pairwise_sum(impostor_scores) / len(impostor_scores)

    # computes variances
    genuine_var = _compute_var(genuine_scores)
    impostor_var = _compute_var(impostor_scores)

    # computes d-prime
    d_prime = math.sqrt(2.0) * abs(genuine_mean - impostor_mean) / math.sqrt(genuine_var + impostor_var)
    return d_prime


# Computes TMR.
def compute_tmr(observations, threshold, is_similarity=True):
    fmr = compute_fmr(observations, threshold, is_similarity)
    if fmr == float('inf'):
        return float('inf')
    else:
        return 1.0 - fmr


# Computes TNMR.
def compute_tnmr(observations, threshold, is_similarity=True):
    fnmr = compute_fnmr(observations, threshold, is_similarity)
    if fnmr == float('inf'):
        return float('inf')
    else:
        return 1.0 - fnmr


# Plots the FMR x FNMR AUCs of the given list of observations.
# Parameter <observation_list> is a list of (observation_data, is_similarity) pairs.
def plot_fmr_fnmr_auc(observation_list):
    aucs = []
    fmrs = []
    fnmrs = []

    for i in range(len(observation_list)):
        observations = observation_list[i][0]  # observation data
        is_similarity = observation_list[i][1]  # is similarity?

        auc, fmr, fnmr = compute_fmr_fnmr_auc(observations, is_similarity)
        aucs.append(auc)
        fmrs.append(fmr)
        fnmrs.append(fnmr)

    plt.xlabel('FMR')
    plt.ylabel('FNMR')

    for i in range(len(fmrs)):
        plt.plot(fmrs[i], fnmrs[i], label='AUC: ' + '{:f}'.format(aucs[i]))

    plt.legend()
    plt.show()


# Usage example
file_a = 'observations_a_similarities.csv'
observations_a = load_data(file_a)
fnmr_a, fmr_a, thr_a = compute_fmr_fnmr_eer(observations_a, is_similarity=True)
auc_a, _, _ = compute_fmr_fnmr_auc(observations_a, is_similarity=True)
d_prime_a = compute_d_prime(observations_a)
print('FNMR:', fnmr_a, 'FMR:', fmr_a, 'THR:', thr_a, 'AUC:', auc_a, 'D-PRIME:', d_prime_a)

file_b = 'observations_b_dissimilarities.csv'
observations_b = load_data(file_b)
fnmr_b, fmr_b, thr_b = compute_fmr_fnmr_eer(observations_b, is_similarity=False)
auc_b, _, _ = compute_fmr_fnmr_auc(observations_b, is_similarity=False)
d_prime_b = compute_d_prime(observations_b)
print('FNMR:', fnmr_b, 'FMR:', fmr_b, 'THR:', thr_b, 'AUC:', auc_b, 'D-PRIME:', d_prime_b)

plot_fmr_fnmr_auc([(observations_a, True), (observations_b, False)])
