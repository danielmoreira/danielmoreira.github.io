# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2020
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Iris Recognition
# TODO: Test script. Better description will be added soon.
# Language: Python 3

import a_acquire
import b_enhance_mp  # b_enhance
import c_describe
import d_match

# Test script.
# TODO: Better description will be added soon.

iris_file_path_1 = 'data/iris1.png'
iris_file_path_2 = 'data/iris2.png'
iris_file_path_3 = 'data/iris3.png'

filters_file_path = 'data/tobii_17_05_ICA_filters/filters.txt'

iris_1 = a_acquire.acquire_from_file(iris_file_path_1, view=False)
iris_2 = a_acquire.acquire_from_file(iris_file_path_2, view=False)
iris_3 = a_acquire.acquire_from_file(iris_file_path_3, view=False)

norm_iris_1, norm_mask_1 = b_enhance_mp.enhance(iris_1, view=False)  # b_enhance.enhance(iris_1)
norm_iris_2, norm_mask_2 = b_enhance_mp.enhance(iris_2, view=False)  # b_enhance.enhance(iris_2)
norm_iris_3, norm_mask_3 = b_enhance_mp.enhance(iris_3, view=False)  # b_enhance.enhance(iris_3)

descriptions_1 = c_describe.describe(norm_iris_1, filters_file_path, view=False)
descriptions_2 = c_describe.describe(norm_iris_2, filters_file_path, view=False)
descriptions_3 = c_describe.describe(norm_iris_3, filters_file_path, view=False)

distance_12 = d_match.match(descriptions_1, norm_mask_1, descriptions_2, norm_mask_2)
print('Distance 12:', distance_12)

distance_21 = d_match.match(descriptions_2, norm_mask_2, descriptions_1, norm_mask_1)
print('Distance 21:', distance_21)

distance_13 = d_match.match(descriptions_1, norm_mask_1, descriptions_3, norm_mask_3)
print('Distance 13:', distance_13)

distance_23 = d_match.match(descriptions_2, norm_mask_2, descriptions_3, norm_mask_3)
print('Distance 23:', distance_23)
