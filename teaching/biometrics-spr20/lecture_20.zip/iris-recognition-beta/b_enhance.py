# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2020
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Iris Recognition
# 02. Module to enhance iris samples, aiming at further feature extraction.
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/),
# and SciPy (https://www.scipy.org/).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python==3.4.2.17";
# "pip3 install scipy".

import math
import numpy
import cv2
from scipy.ndimage import gaussian_filter1d

IRIS_WIDTH = 640
IRIS_BLUR_SIZE = 31
MIN_PUPIL_R = 20
MAX_PUPIL_R = 50
MIN_PUPIL_X = 220
MAX_PUPIL_X = 420
MIN_PUPIL_Y = 140
MAX_PUPIL_Y = 340
MIN_IRIS_R = 100
MAX_IRIS_R = 200
PIXEL_STEP = 5
SMOOTH_SIGMA = 1.2
NORM_IRIS_SECTOR_COUNT = 1000
NORM_IRIS_WIDTH = 512
NORM_IRIS_HEIGHT = 64


######################
# Auxiliary methods. #
######################

# TODO
# Description will be added soon.
def _circular_integrate(iris, x0, y0, r, sampling=360.0):
    # iris image dimensions
    rows, cols = iris.shape

    # holds the pixel values within the given/target circumference
    pixel_values = []

    # for each discrete angle within [0 rad, 2pi rad]...
    for angle in numpy.arange(0, 2.0 * numpy.pi, 2.0 * numpy.pi / sampling):
        # current cartesian (x, y) circumference pixel position
        x = int(round(x0 + r * math.sin(angle)))
        y = int(round(y0 + r * math.cos(angle)))

        # returns None if the current (x, y) position is not valid (i.e., within the iris image bounds)
        if x < 0 or x >= cols or y < 0 or y >= rows:
            return None

        # updates the sum of pixel values
        pixel_values.append(float(iris[y, x]))

    # returns the sum of pixel values normalized by the number of collected values
    return numpy.array(pixel_values)


# TODO
# Description will be added soon.
def _circular_differentiate(iris, x0, y0, r):
    # computes circular integral values for radius 'r' and 'r+1' pixels
    values = []
    for current_r in [r, r + 1]:
        v = _circular_integrate(iris, x0, y0, current_r)
        if v is not None:
            values.append(v)

    # returns None if there are not two values to compute local derivative
    if len(values) < 2:
        return None

    # returns the local circular derivative
    return numpy.mean(abs(values[0] - values[1]))


# TODO
# Description will be added soon.
def _fit_circumference(iris, min_r, max_r, min_x, max_x, min_y, max_y, pixel_step, smooth_sigma):
    # range of possible radius values
    r_values = range(min_r, max_r, pixel_step)

    # collects many circumferences
    circs = []
    for x0 in range(min_x, max_x, pixel_step):
        for y0 in range(min_y, max_y, pixel_step):
            v_r = []
            circs_r = []

            for r in r_values:
                v = _circular_differentiate(iris, x0, y0, r)
                if v is not None:
                    v_r.append(v)
                    circs_r.append(r)

            if len(v_r) > 0:
                v_r = gaussian_filter1d(v_r, sigma=smooth_sigma)

                # takes the circumference with maximum derivative
                max_ind = numpy.argmax(v_r)
                circs.append((v_r[max_ind], x0, y0, circs_r[max_ind]))

    # returns None if there are no circumferences available
    if len(circs) == 0:
        return None

    # returns the best circumference
    best_c = sorted(circs, key=lambda x: (x[0], x[3]), reverse=True)[0]
    return best_c[1], best_c[2], best_c[3]  # x position, y position, radius


#######################
# Main methods/steps. #
#######################

# TODO
# Description will be added soon.
def _01_preprocess(iris, output_width, view=False):
    # makes the iris grayscale, if it is still colored
    if len(iris.shape) > 2 and iris.shape[2] > 1:  # more than one channel?
        iris = cv2.cvtColor(iris, cv2.COLOR_BGR2GRAY)

    # resizes the iris to present a width of <output_width> pixels, keeping original aspect ratio
    aspect_ratio = float(iris.shape[0]) / iris.shape[1]
    height = int(round(output_width * aspect_ratio))
    iris = cv2.resize(iris, (output_width, height))

    # shows the obtained iris, if it is the case
    if view:
        cv2.imshow('Preprocessing, press any key.', iris)
        cv2.waitKey(0)

    print('[INFO] Preprocessed iris.')
    return iris


# TODO
# Description will be added soon.
def _02_mask_pupil_and_specular_reflections(iris, blur_size, view=False):
    # blurred version of the iris
    blurred_iris = cv2.medianBlur(iris, blur_size)
    blurred_iris = cv2.equalizeHist(blurred_iris)
    if view:
        cv2.imshow('Blurred iris, press any key.', blurred_iris)
        cv2.waitKey(0)

    # pupil mask
    _, pupil_mask = cv2.threshold(blurred_iris, 1, 255, cv2.THRESH_BINARY)
    if view:
        cv2.imshow('Pupil mask, press any key.', pupil_mask)
        cv2.waitKey(0)

    # mask of specular reflections
    iris = cv2.equalizeHist(iris)
    _, specr_mask = cv2.threshold(iris, 254, 255, cv2.THRESH_BINARY_INV)
    if view:
        cv2.imshow('Specular reflection mask, press any key.', specr_mask)
        cv2.waitKey(0)

    print('[INFO] Computed pupil and specular reflection masks.')
    return blurred_iris, pupil_mask, specr_mask


# TODO
# Description will be added soon.
def _03_detect_iris_boundaries(blurred_iris, pupil_mask,
                               min_pupil_r, max_pupil_r,
                               min_pupil_x, max_pupil_x,
                               min_pupil_y, max_pupil_y,
                               min_iris_r, max_iris_r,
                               pixel_step, smooth_sigma, view=False):
    # # gets the pupil circumference
    # pupil = _fit_circumference(pupil_mask, min_pupil_r, max_pupil_r, min_pupil_x, max_pupil_x, min_pupil_y, max_pupil_y,
    #                            pixel_step, smooth_sigma)
    #
    # # returns None if there is no pupil circumference
    # if pupil is None:
    #     return None
    #
    # # gets the limbus circumference
    # limbus = _fit_circumference(blurred_iris, min_iris_r, max_iris_r, pupil[0] - pupil[2], pupil[0] + pupil[2],
    #                             pupil[1] - pupil[2], pupil[1] + pupil[2], 5, 1.2)
    #
    # # returns None if there is no limbus circumference
    # if limbus is None:
    #     return None
    #
    # # shows the circumferences, if it is the case
    # if view:
    #     blurred_iris = cv2.cvtColor(blurred_iris, cv2.COLOR_GRAY2BGR)
    #     cv2.circle(blurred_iris, (pupil[0], pupil[1]), pupil[2], (0, 255, 0), 1)
    #     cv2.circle(blurred_iris, (limbus[0], limbus[1]), limbus[2], (0, 255, 0), 1)
    #     cv2.imshow('Pupil and limbus, press any key.', blurred_iris)
    #     cv2.waitKey(0)
    #
    # # returns pupil and limbus
    # print('[INFO] Detected limbus and pupillary boundaries.')
    # return pupil, limbus

    # gets the pupil circumference
    pupil_edge = cv2.Canny(pupil_mask, 1, 1)

    pupil = (0, 0, 0)
    circles = cv2.HoughCircles(pupil_edge, cv2.HOUGH_GRADIENT, 1, IRIS_WIDTH, param1=2, param2=1)

    if circles is None:
        return None

    for c in circles[0]:
        if c[2] > pupil[2]:
            pupil = (int(round(c[0])), int(round(c[1])), int(round(c[2])))

    # gets the limbus circumference
    limbus = _fit_circumference(blurred_iris, pupil[2] + 50, pupil[2] * 4,
                                pupil[0] - pupil[2], pupil[0] + pupil[2],  # iris center lies within the pupil (x-axis)
                                pupil[1] - pupil[2], pupil[1] + pupil[2],  # iris center lies within the pupil (y-axis)
                                pixel_step, smooth_sigma)

    # returns None if there is no limbus circumference
    if limbus is None:
        return None

    # shows the circumferences, if it is the case
    if view:
        iris = cv2.cvtColor(blurred_iris, cv2.COLOR_GRAY2BGR)
        cv2.circle(iris, (pupil[0], pupil[1]), pupil[2], (0, 255, 0), 1)
        cv2.circle(iris, (limbus[0], limbus[1]), limbus[2], (0, 255, 0), 1)
        cv2.imshow('Pupil and limbus, press any key.', iris)
        cv2.waitKey(0)

    # return pupil and limbus
    print('[INFO] Detected limbus and pupillary boundaries.')
    return pupil, limbus


# TODO
# Description will be added soon.
def _04_normalize_iris(iris, pupil, limbus, pupil_mask, specular_reflection_mask, sector_count,
                       norm_iris_width, norm_iris_height, view=False):
    # combines pupil and specular reflection masks
    iris_mask = cv2.bitwise_and(pupil_mask, specular_reflection_mask)

    # iris band width
    iris_band_width = limbus[2] - pupil[2]

    # output normalized iris
    norm_iris = numpy.zeros((iris_band_width, sector_count), numpy.uint8)
    norm_mask = numpy.zeros((iris_band_width, sector_count), numpy.uint8)

    # for each sector...
    j = 0
    for angle in numpy.arange(0, 2.0 * numpy.pi, 2.0 * numpy.pi / sector_count):
        sector = numpy.zeros((iris_band_width, 1), numpy.uint8)
        sector_mask = numpy.zeros((iris_band_width, 1), numpy.uint8)

        # for each iris band pixel...
        for i in range(iris_band_width):
            # cartesian position
            x = int(round(pupil[0] + (pupil[2] + i + 1) * math.sin(angle)))
            y = int(round(pupil[1] + (pupil[2] + i + 1) * math.cos(angle)))

            # pixel-value transference
            norm_iris[i, j] = iris[y, x]
            norm_mask[i, j] = iris_mask[y, x]

        # next sector
        j = j + 1

    # resizes the normalized iris and mask
    norm_iris = cv2.resize(norm_iris, (norm_iris_width, norm_iris_height), interpolation=cv2.INTER_CUBIC)
    norm_iris = cv2.equalizeHist(norm_iris)

    norm_mask = cv2.resize(norm_mask, (norm_iris_width, norm_iris_height), interpolation=cv2.INTER_CUBIC)
    _, norm_mask = cv2.threshold(norm_mask, 0, 255, cv2.THRESH_BINARY)

    if view:
        cv2.imshow('Normalized iris, press any key.', norm_iris)
        cv2.waitKey(0)

        cv2.imshow('Normalized iris mask, press any key.', norm_mask)
        cv2.waitKey(0)

    # returns the obtained normalized iris and mask
    print('[INFO] Obtained normalized version of the given iris.')
    return norm_iris, norm_mask


################
# Main method. #
################

# TODO
# Description will be added soon.
def enhance(iris, view=False):
    # pre-processes the iris
    pp_iris = _01_preprocess(iris, output_width=IRIS_WIDTH, view=view)

    # masks the pupil and specular reflections
    blurred_iris, pupil_mask, specr_mask = _02_mask_pupil_and_specular_reflections(pp_iris, IRIS_BLUR_SIZE, view=view)

    # finds the pupil and iris positions
    pupil_limbus = _03_detect_iris_boundaries(blurred_iris, pupil_mask,
                                              min_pupil_r=MIN_PUPIL_R, max_pupil_r=MAX_PUPIL_R,
                                              min_pupil_x=MIN_PUPIL_X, max_pupil_x=MAX_PUPIL_X,
                                              min_pupil_y=MIN_PUPIL_Y, max_pupil_y=MAX_PUPIL_Y,
                                              min_iris_r=MIN_IRIS_R, max_iris_r=MAX_IRIS_R,
                                              pixel_step=PIXEL_STEP, smooth_sigma=SMOOTH_SIGMA, view=view)

    if pupil_limbus is None:
        return None

    # computes the normalized iris
    norm_iris, norm_mask = _04_normalize_iris(pp_iris, pupil_limbus[0], pupil_limbus[1], pupil_mask, specr_mask,
                                              NORM_IRIS_SECTOR_COUNT, NORM_IRIS_WIDTH, NORM_IRIS_HEIGHT, view=view)

    return norm_iris, norm_mask
