# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2020
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Iris Recognition
# 04. Module to match iris descriptions.
# Language: Python 3
# Needed libraries: TODO.
# Quick install (with PyPI - https://pypi.org/): TODO.

import numpy
import cv2

#########################
# Configuration values. #
#########################

ROTATIONS = [-10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


######################
# Auxiliary methods. #
######################

# TODO
# Description will be added soon.
def _rotate_norm_image(image, rotation):
    output = numpy.zeros(image.shape, image.dtype)

    if rotation == 0:
        return image

    else:
        output[:, rotation:] = image[:, :-rotation]
        output[:, :rotation] = image[:, -rotation:]

    return output


# TODO
# Description will be added soon.
def _compute_norm_hamming_distance(description_1, mask_1, description2, mask_2):
    # combines both masks
    comb_mask = cv2.bitwise_and(mask_1, mask_2)

    # computes the number of bits up within the resulting mask
    bit_up_count = numpy.sum(comb_mask > 0)

    # hamming distance
    xor_output = cv2.bitwise_xor(description_1, description2)
    xor_output = cv2.bitwise_and(xor_output, xor_output, mask=comb_mask)
    dist = numpy.sum(xor_output > 0)

    # returns the normalized hamming distance
    return float(dist) / bit_up_count


# TODO
# Description will be added soon.
def match(descriptions_1, mask_1, descriptions_2, mask_2):
    # holds the distances computed for each rotation
    rot_distances = []

    # for each rotation...
    for rotation in ROTATIONS:
        # holds the BSIF-filter-wise pairwise description distances
        distances = []

        # for each BSIF-filter-wise description
        for i in range(len(descriptions_1)):  # could be "for i in range(len(descriptions_2)):"
            # rotates description 2 and compares to 1
            desc_1 = descriptions_1[i]
            rot_desc_2 = _rotate_norm_image(descriptions_2[i], rotation)
            rot_mask_2 = _rotate_norm_image(mask_2, rotation)

            # computes and stores the current distance
            distances.append(_compute_norm_hamming_distance(desc_1, mask_1, rot_desc_2, rot_mask_2))

        # takes the resulting rotation distance as the average
        rot_distances.append(numpy.mean(distances))

    # returns the final distance as the minimum one (best rotation match)
    print('[INFO] Computed normalized Hamming distance.')
    return numpy.min(rot_distances)
