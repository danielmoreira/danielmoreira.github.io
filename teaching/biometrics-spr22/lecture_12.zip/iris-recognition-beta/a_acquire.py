# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2022
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Iris Recognition
# 01. Acquisition-module stub.
# Language: Python 3
# Needed libraries: OpenCV (https://opencv.org/)
# Quick install (with PyPI - https://pypi.org/):
# execute "pip3 install opencv-contrib-python" on command shell.

import cv2


# Stub function to acquire an iris sample from a file, given its path.
# The iris is acquired with a single channel (grayscale).
# Parameters
# file_path: The path to the image file containing one iris sample.
# view: TRUE if loaded iris must be shown in a proper window, FALSE otherwise.
def acquire_from_file(file_path, view=False):
    # reads the iris image from the given file path
    # and returns it
    iris = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)

    # show the read iris, if it is the case
    if view:
        cv2.imshow('press any key', iris)
        cv2.waitKey(0)

    print('[INFO] Acquired iris from file', file_path + '.')
    return iris

# TODO
# New functions may be added here, targeting either:
# 1. Solution test execution (loading of various genuine and impostor iris pairs); or
# 2. Enrollment scenario (loading of iris + ID to enroll in a system); or
# 3. Verification scenario (loading of iris + ID, to verify claimed identity); or
# 4. Recognition scenario (loading of iris, to find identity).
