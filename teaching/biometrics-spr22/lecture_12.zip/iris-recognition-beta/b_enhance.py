# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2022
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Iris Recognition
# 02. Module to enhance iris samples, aiming at further feature extraction.
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/),
# Scikit-Image (https://scikit-image.org/docs/dev/api/skimage.html).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python";
# "pip3 install scikit-image".

import math
import numpy
import cv2
import skimage.morphology

# Configuration parameters.
# Width of the acquired iris image after normalization; the original aspect ratio is kept.
IRIS_WIDTH = 640

# Neighborhood, in pixels, used to blur the iris image content, to focus on the pupil and limbus edges.
IRIS_BLUR_SIZE = 31

# Minimum expected radius, in pixels of the pupil of the acquired iris.
PUPIL_MIN_RADIUS = 20

# Dimensions, in pixels, of the acquired iris after rectangular normalization.
NORM_IRIS_SECTOR_COUNT = 1000
NORM_IRIS_WIDTH = 512
NORM_IRIS_HEIGHT = 64


# Preprocesses the given <iris> image (numpy 2D array with uint8 pixel values).
# Provide <view> as True if you want to see the result of computations. Will ask and wait for key press.
# Returns the preprocessed iris as a numpy 2D uint8 array.
def _01_preprocess(iris, view=False):
    # makes the iris grayscale, if it is still colored
    if len(iris.shape) > 2 and iris.shape[2] > 1:  # more than one channel?
        iris = cv2.cvtColor(iris, cv2.COLOR_BGR2GRAY)

    # resizes the iris to present a width of <output_width> pixels, keeping original aspect ratio
    aspect_ratio = float(iris.shape[0]) / iris.shape[1]
    height = int(round(IRIS_WIDTH * aspect_ratio))
    iris = cv2.resize(iris, (IRIS_WIDTH, height))

    # shows the obtained iris, if it is the case
    if view:
        cv2.imshow('Preprocessing, press any key.', iris)
        cv2.waitKey(0)

    print('[INFO] Preprocessed iris.')
    return iris


# Detects the pupil and limbus circles over the given <iris>.
# Provide <view> as True if you want to see the result of computations. Will ask and wait for key press.
# Returns the pupil and limbus circles (x_center, y_center, radius), in pixels.
# Returns None is no pupil or limbus are found.
def _02_detect_pupil_and_limbus(iris, view=False):
    # blurred version of the iris (small details are ignored)
    blur_iris = cv2.medianBlur(iris, IRIS_BLUR_SIZE)

    # 1. pupil detection
    # pupil edge detection
    pupil_edge = (cv2.normalize(blur_iris, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX) > 10).astype(
        numpy.uint8) * 255  # pupil might be black (0)
    pupil_edge = cv2.Canny(pupil_edge, 100, 200)  # only pupil border might be visible, now

    # Blob detection to compute pupil's center and radius
    pupil_detection = cv2.SimpleBlobDetector_Params()
    pupil_detection.filterByArea = True
    pupil_detection.minArea = int(math.pi * PUPIL_MIN_RADIUS ** 2)
    pupil_detection.maxArea = int(math.pi * (PUPIL_MIN_RADIUS * 4) ** 2)
    pupil_detector = cv2.SimpleBlobDetector_create(parameters=pupil_detection)
    keypoints = pupil_detector.detect(pupil_edge)
    if keypoints is not None and len(keypoints) > 0:
        pupil_circle = (int(keypoints[0].pt[0]), int(keypoints[0].pt[1]), int(keypoints[0].size / 2))
    else:
        return None

    # 2. limbus detection
    limbus_step = int(IRIS_WIDTH / 4)
    limbus_mask = numpy.zeros(iris.shape, numpy.uint8)
    cv2.rectangle(limbus_mask, (pupil_circle[0] - limbus_step, pupil_circle[1] - limbus_step),
                  (pupil_circle[0] + limbus_step, pupil_circle[1] + limbus_step), (255, 255, 255), -1)

    limbus_edge = numpy.abs(iris - blur_iris)  # borders might be highlighted in white
    limbus_edge = cv2.bitwise_and(limbus_edge, limbus_edge, mask=limbus_mask)  # focus on pupil neighborhood
    limbus_edge = cv2.medianBlur(limbus_edge, IRIS_BLUR_SIZE)  # keeps only border information
    _, limbus_edge = cv2.threshold(limbus_edge, 200, 255, cv2.THRESH_BINARY)  # image binarization; borders are white
    limbus_edge = skimage.morphology.skeletonize(limbus_edge / 255).astype(numpy.uint8) * 255  # limbus skeletonization
    limbus_edge = cv2.morphologyEx(limbus_edge, cv2.MORPH_DILATE,
                                   cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))  # dilates limbus border

    # Hough transform to compute limbus' center and radius
    limbus_circle = cv2.HoughCircles(limbus_edge, cv2.HOUGH_GRADIENT, IRIS_WIDTH / 100, IRIS_WIDTH,
                                     minRadius=pupil_circle[2], maxRadius=int(IRIS_WIDTH / 4))
    if limbus_circle is not None:
        limbus_circle = numpy.round(limbus_circle[0, :]).astype("int")[0]
    else:
        return None

    # shows the obtained pupil and limbus borders, if it is the case
    if view:
        iris_copy = cv2.cvtColor(iris, cv2.COLOR_GRAY2BGR)
        cv2.circle(iris_copy, pupil_circle[0:2], pupil_circle[2], (0, 255, 0), 1)
        cv2.circle(iris_copy, limbus_circle[0:2], limbus_circle[2], (0, 0, 255), 1)
        cv2.imshow('Pupil and limbus, press any key.', iris_copy)
        cv2.waitKey(0)

    print('[INFO] Detected pupil and limbus.')
    return pupil_circle, limbus_circle


# Computes a mask to remove eye lashes and specular highlights from the given <iris>.
# This process needs the <pupil> and <limbus> circles to execute the proper segmentation.
# Provide <view> as True if you want to see the result of computations. Will ask and wait for key press.
# Returns the computed mask as a numpy 2D uint8 array, which is black (zero) for the areas to be ignored, and
# white (255) for the ones to be processed.
def _03_compute_mask(iris, pupil, limbus, view=False):
    # computed mask
    mask = numpy.zeros(iris.shape, numpy.uint8)

    # adds limbus and pupil regions to the mask
    cv2.circle(mask, limbus[0:2], limbus[2], (255, 255, 255), -1)
    cv2.circle(mask, pupil[0:2], pupil[2], (0, 0, 0), -1)

    # removes eventual eye lashes (black) and specular highlights (white)
    eq_iris = cv2.bitwise_and(iris, iris, mask=mask)
    eq_iris = cv2.equalizeHist(eq_iris)
    _, m_lashes = cv2.threshold(eq_iris, 30, 255, cv2.THRESH_BINARY)
    _, m_specul = cv2.threshold(eq_iris, 250, 255, cv2.THRESH_BINARY_INV)
    mask = cv2.bitwise_and(m_lashes, m_specul, mask=mask)

    # shows the obtained mask, if it is the case
    if view:
        mask_iris = cv2.bitwise_and(iris, iris, mask=mask)
        cv2.imshow('Masked iris.', mask_iris)
        cv2.waitKey(0)

    return mask


# Normalizes the given <iris> making it a proper rectangle (rubber sheet algorithm).
# This process needs the <pupil> and <limbus> circles, as well as the iris useful content <mask>
# to execute the proper normalization.
# Provide <view> as True if you want to see the result of computations. Will ask and wait for key press.
# Returns the normalized iris and respective normalized mask as numpy 2D uint8 arrays.
def _04_normalize_iris(iris, pupil, limbus, mask, view=False):
    # iris band width
    iris_band_width = limbus[2] - pupil[2]

    # output normalized iris
    norm_iris = numpy.zeros((iris_band_width, NORM_IRIS_SECTOR_COUNT), numpy.uint8)
    norm_mask = numpy.zeros((iris_band_width, NORM_IRIS_SECTOR_COUNT), numpy.uint8)

    # for each sector...
    j = 0
    for angle in numpy.arange(0, 2.0 * numpy.pi, 2.0 * numpy.pi / NORM_IRIS_SECTOR_COUNT):
        # for each iris band pixel...
        for i in range(iris_band_width):
            # cartesian position
            x = int(round(pupil[0] + (pupil[2] + i + 1) * math.sin(angle)))
            y = int(round(pupil[1] + (pupil[2] + i + 1) * math.cos(angle)))

            # pixel-value transference
            norm_iris[i, j] = iris[y, x]
            norm_mask[i, j] = mask[y, x]

        # next sector
        j = j + 1

    # resizes the normalized iris and mask
    norm_iris = cv2.resize(norm_iris, (NORM_IRIS_WIDTH, NORM_IRIS_HEIGHT), interpolation=cv2.INTER_CUBIC)
    norm_iris = cv2.equalizeHist(norm_iris)

    norm_mask = cv2.resize(norm_mask, (NORM_IRIS_WIDTH, NORM_IRIS_HEIGHT), interpolation=cv2.INTER_CUBIC)
    _, norm_mask = cv2.threshold(norm_mask, 0, 255, cv2.THRESH_BINARY)

    if view:
        cv2.imshow('Normalized iris and mask, press any key.', numpy.vstack((norm_iris, norm_mask)))
        cv2.waitKey(0)

    # returns the obtained normalized iris and mask
    print('[INFO] Obtained normalized version of the given iris.')
    return norm_iris, norm_mask


# Enhances the given <iris> image (numpy 2-D array with uint8 pixel values).
# Provide <view> as True if you want to see the results of computations. Will ask and wait for many key presses.
# Returns the normalized iris and respective normalized mask as numpy 2D uint8 arrays.
def enhance(iris, view=False):
    # pre-processes the iris
    pp_iris = _01_preprocess(iris, view=view)

    # detects pupil and limbus borders
    pupil_limbus = _02_detect_pupil_and_limbus(pp_iris, view=view)
    if pupil_limbus is None:
        return None

    # computes the mask that will remove noise from the iris texture
    mask = _03_compute_mask(pp_iris, pupil_limbus[0], pupil_limbus[1], view=view)

    # computes the normalized iris
    norm_iris, norm_mask = _04_normalize_iris(pp_iris, pupil_limbus[0], pupil_limbus[1], mask, view=view)

    return norm_iris, norm_mask
