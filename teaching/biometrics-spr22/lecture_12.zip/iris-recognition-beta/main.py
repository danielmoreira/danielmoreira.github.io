# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2022
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Iris Recognition
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/),
# Scikit-Image (https://scikit-image.org/docs/dev/api/skimage.html), and SciPy (https://www.scipy.org/).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python";
# "pip3 install scikit-image";
# "pip3 install scipy".

import a_acquire
import b_enhance
import c_describe
import d_match

# Test script.

iris_file_path_1 = 'data/eye1.png'
iris_file_path_2 = 'data/eye2.png'

iris_1 = a_acquire.acquire_from_file(iris_file_path_1, view=False)
iris_2 = a_acquire.acquire_from_file(iris_file_path_2, view=False)

norm_iris_mask_iris_1 = b_enhance.enhance(iris_1, view=True)
norm_iris_mask_iris_2 = b_enhance.enhance(iris_2, view=True)

if norm_iris_mask_iris_1 is not None and norm_iris_mask_iris_2 is not None:
    norm_iris_1, mask_iris_1 = norm_iris_mask_iris_1
    norm_iris_2, mask_iris_2 = norm_iris_mask_iris_2

    description_1 = c_describe.describe(norm_iris_1, view=False)
    description_2 = c_describe.describe(norm_iris_2, view=False)

    distance = d_match.match(description_1, mask_iris_1, description_2, mask_iris_2)
    print('Distance:', distance)

else:
    print('Could not normalize iris.')
