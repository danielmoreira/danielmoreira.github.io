# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2022
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Iris Recognition
# 03. Module to describe iris texture.
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/), and SciPy (https://www.scipy.org/).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python";
# "pip3 install scipy".

import numpy
import cv2
import scipy.io
import scipy.signal

# Configuration parameters.
# Size, in pixels, of the BSIF filters used to convolve the target iris image.
FILTER_SIZE = 15

# Number of BSIF filters used to convolve the target iris image.
FILTER_COUNT = 7

# File path of the .mat file used to store the BSIF filters, previously computer with ICA.
FILTER_FILE_PATH = 'data/tobii_15_07_ICA_filters/ICAtextureFilters_15x15_7bit.mat'


# Describes the given normalized iris <norm_iris> with BSIF filters.
# Provide <view> as True if you want to see the results of computations. Will ask and wait for many key presses.
# Returns the obtained binary descriptions.
def _01_bsif_describe(norm_iris, view=False):
    # output binary code
    descriptions = numpy.zeros((norm_iris.shape[0], norm_iris.shape[1], FILTER_COUNT))

    # prepares the iris image to be convolved with the BSIF filters
    offset = int(FILTER_SIZE / 2)
    iris_wrap = numpy.zeros((offset * 2 + norm_iris.shape[0], offset * 2 + norm_iris.shape[1]))

    iris_wrap[:offset, :offset] = norm_iris[-offset:, -offset:]
    iris_wrap[:offset, offset:-offset] = norm_iris[-offset:, :]
    iris_wrap[:offset, -offset:] = norm_iris[-offset:, :offset]

    iris_wrap[offset:-offset, :offset] = norm_iris[:, -offset:]
    iris_wrap[offset:-offset, offset:-offset] = norm_iris
    iris_wrap[offset:-offset, -offset:] = norm_iris[:, :offset]

    iris_wrap[-offset:, :offset] = norm_iris[:offset, -offset:]
    iris_wrap[-offset:, offset:-offset] = norm_iris[:offset, :]
    iris_wrap[-offset:, -offset:] = norm_iris[:offset, :offset]

    # BSIF filters learned from the eye-tracking data
    filters = scipy.io.loadmat(FILTER_FILE_PATH)['ICAtextureFilters']

    # for each filter, applies the convolution with the iris image
    for i in range(FILTER_COUNT):
        conv = scipy.signal.convolve2d(iris_wrap, numpy.rot90(filters[:, :, FILTER_COUNT - i - 1], 2), mode='valid')
        descriptions[:, :, i] = conv > 0.0  # binarization

        # shows the current convolved image, if it is the case
        if view:
            view_conv = cv2.normalize(conv, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX).astype(numpy.uint8)
            cv2.imshow('Filtered iris, press any key.', view_conv)
            cv2.waitKey(0)

            view_code = descriptions[:, :, i].astype(numpy.uint8) * 255
            cv2.imshow('Iris code, press any key.', view_code)
            cv2.waitKey(0)

    return descriptions


# Describes the given normalized iris <norm_iris> with BSIF filters.
# Provide <view> as True if you want to see the results of computations. Will ask and wait for many key presses.
# Returns the obtained binary descriptions.
def describe(norm_iris, view=False):
    return _01_bsif_describe(norm_iris, view=view)
