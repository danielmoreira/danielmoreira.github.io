# -*- coding: utf-8 -*-
"""
Created on Mon Apr 18 22:50:30 2016

@author: utkarsh
"""
from third_party.ud.ridge_segment import ridge_segment
from third_party.ud.ridge_orient import ridge_orient
from third_party.ud.ridge_freq import ridge_freq
from third_party.ud.ridge_filter import ridge_filter

# import cv2
import numpy


def image_enhance(img):
    blksze = 16
    thresh = 0.1
    normim, mask = ridge_segment(img, blksze, thresh)  # normalise the image and find a ROI

    # cv2.imshow('norm', normim)
    # cv2.waitKey()
    # cv2.imshow('mask', mask.astype(numpy.uint8) * 255)
    # cv2.waitKey()

    gradientsigma = 1
    blocksigma = 7
    orientsmoothsigma = 7
    orientim = ridge_orient(normim, gradientsigma, blocksigma, orientsmoothsigma)  # find orientation of every pixel

    # cv2.imshow('orientim', orientim)
    # cv2.waitKey()

    blksze = 38
    windsze = 5
    min_wave_length = 5
    max_wave_length = 15
    freq, medfreq = ridge_freq(normim, mask, orientim, blksze, windsze, min_wave_length,
                               max_wave_length)  # find the overall frequency of ridges

    # cv2.imshow('freqim', freq)
    # cv2.waitKey()
    # print(medfreq)

    freq = medfreq * mask
    kx = 0.65
    ky = 0.65
    newim = ridge_filter(normim, orientim, freq, kx, ky)  # create gabor filter and do the actual filtering

    # cv2.imshow('newim', newim)
    # cv2.waitKey()

    # th, bin_im = cv2.threshold(np.uint8(newim),0,255,cv2.THRESH_BINARY)
    return (newim < -3).astype(numpy.uint8) * 255, mask.astype(numpy.uint8) * 255
