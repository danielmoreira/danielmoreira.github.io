# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2022
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Fingerprint Recognition
# 03. Module to detect and describe minutiae.
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python==3.4.2.17".

import math
import numpy
import cv2

# Configuration parameters.
# Number of pixel neighborhood expansions (in pixels) to estimate ridge angle.
NEIGHBORHOOD_EXPANSION = 5

# Ridge angle magnitude representation size (in pixels).
RIDGE_ANGLE_MAG = 5

# Minimum acceptable distance between a minutiae and the fingerprint mask border, in pixels.
MIN_MASK_DIST = 10

# Minimum acceptable distance between two minutiae that have opposing angles (i.e., absolute diff. is pi), in pixels.
MIN_MINUTIAE_DIST = 10

# Tolerance, in radians, to consider two angles opposing ones (i.e., absolute diff. is pi).
OPPOSING_ANG_TOLE = math.pi / 16


# Draws, on the given <fingerprint> image, the given <ridge_endings> and <ridge_bifurcations> minutiae.
# Parameter <msg> is a string used to compose the title of the GUI window that will show the resulting image.
# No data is returned.
def _draw_minutiae(fingerprint, ridge_endings, ridge_bifurcations, msg):
    # ridge endings will be red squares, while bifurcations will be green squares
    img = (fingerprint > 0).astype(numpy.uint8) * 255
    img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

    for ridge_ending in ridge_endings:
        p = (int(ridge_ending[0]), int(ridge_ending[1]))
        cv2.rectangle(img, (p[0] - 1, p[1] - 1), (p[0] + 2, p[1] + 2), (0, 0, 255), 1)

        delta_x = int(round(numpy.cos(ridge_ending[2]) * RIDGE_ANGLE_MAG))
        delta_y = int(round(numpy.sin(ridge_ending[2]) * RIDGE_ANGLE_MAG))
        cv2.line(img, (p[0], p[1]), (p[0] + delta_x, p[1] + delta_y), (0, 255, 255), 1)

    for bifurcation in ridge_bifurcations:
        p = (int(bifurcation[0]), int(bifurcation[1]))
        cv2.rectangle(img, (p[0] - 1, p[1] - 1), (p[0] + 2, p[1] + 2), (0, 255, 0), 1)

        delta_x = int(round(numpy.cos(bifurcation[2]) * RIDGE_ANGLE_MAG))
        delta_y = int(round(numpy.sin(bifurcation[2]) * RIDGE_ANGLE_MAG))
        cv2.line(img, (p[0], p[1]), (p[0] + delta_x, p[1] + delta_y), (0, 255, 255), 1)

    cv2.imshow(msg + ' minutiae, press any key.', img)
    cv2.waitKey(0)


# Recursive method that expands the content of a ridge pixel towards its immediate neighborhood.
# Parameters:
# <fingerprint> - The image of the fingerprint whose minutiae are being extracted.
# <ridge_position> - The (x, y) position of the ridge pixel, where the expansion starts from.
# <interest_pixels> - List of (x, y) positions of the ridge pixels recursively expanded so far.
# <processed_pixels> - List of (x, y) positions of the ridge pixels recursively analysed so far.
# <recursion_control> - Supporting flag to control number of recursions. Provide a number larger than 0.
# No data is returned. The important results (ridge pixels) will be stored in <interest_pixels>.
def _ridge_expand(fingerprint, ridge_position, interest_pixels, processed_pixels, recursion_control):
    # if it is time to stop recursion, does nothing
    if recursion_control <= 0:
        return

    # else, time to process the pixel at the current ridge position
    else:
        # registers current pixel, to avoid further re-computations
        processed_pixels.append(ridge_position)

        # if current pixel is not a ridge one, does nothing
        if fingerprint[ridge_position[1], ridge_position[0]] == 0:
            return

        # else, time to process the current pixel's immediate neighborhood
        else:
            for x in range(ridge_position[0] - 1, ridge_position[0] + 2):
                for y in range(ridge_position[1] - 1, ridge_position[1] + 2):
                    # is neighbor pixel a ridge type and not computed before?
                    if fingerprint[y, x] == 1 and (x, y) not in processed_pixels:
                        # registers as pixel of interest
                        interest_pixels.append((x, y))

                        # recursively processes this pixel
                        _ridge_expand(fingerprint, (x, y), interest_pixels, processed_pixels, recursion_control - 1)

    # in the end of the recursion, interest_pixels will have all the neighbor ridge pixels of interest


# Computes the angle of the minutiae that sits on the given <position>, over the given <fingerprint> image.
# Provide <is_ridge_ending> as True if the minutiae is a ridge ending, or as False if it is a bifurcation.
# Returns a tuple (angle, doubt), which expresses the "angle" of the minutiae, in radians, and the "doubt"
# in computing it (as a measure of non-quality; 0 is the highest quality, meaning no doubt at all).
# This method may return None if not able to compute the angle at all.
def _compute_minutiae_angle(fingerprint, position, is_ridge_ending):
    # obtains the pixels of interest in the minutiae neighborhood for computing the ridge angle
    interest_pixels = []
    processed_pixels = []
    _ridge_expand(fingerprint, position, interest_pixels, processed_pixels, NEIGHBORHOOD_EXPANSION)

    # if the minutiae is a ridge ending...
    if is_ridge_ending:
        angles = []
        for pixel in interest_pixels:
            angles.append(math.atan2(pixel[1] - position[1], pixel[0] - position[0]))

        # returns the average of the angles
        if len(angles) > 0:
            return math.atan2(numpy.sum(numpy.sin(angles)), numpy.sum(numpy.cos(angles))), 0.0

    # else, the minutiae is a ridge bifurcation...
    else:
        # finds the three farthest pixels of interest from the minutiae position
        pixel_distances = [(math.sqrt((x - position[0]) ** 2 + (y - position[1]) ** 2), x, y)
                           for (x, y) in interest_pixels]
        pixel_distances.sort(key=lambda v: v[0], reverse=True)

        # guarantees the points are spread out in space
        selected_pixel_distances = [pixel_distances[0]]
        for pd in pixel_distances[1:]:
            far_enough = True

            for spd in selected_pixel_distances:
                if math.sqrt((pd[1] - spd[1]) ** 2 + (pd[2] - spd[2]) ** 2) < 3:
                    far_enough = False
                    break

            if far_enough:
                selected_pixel_distances.append(pd)

            if len(selected_pixel_distances) >= 3:
                break

        # if there are three pixels of interest...
        if len(selected_pixel_distances) == 3:
            # computes the angles for each one of the three farthest pixels of interest
            angles = [math.atan2(y - position[1], x - position[0]) for (_, x, y) in selected_pixel_distances]

            # finds the two angles that are the most similar
            diff01 = math.fabs(math.atan2(math.sin(angles[0] - angles[1]), math.cos(angles[0] - angles[1])))
            diff02 = math.fabs(math.atan2(math.sin(angles[0] - angles[2]), math.cos(angles[0] - angles[2])))
            diff12 = math.fabs(math.atan2(math.sin(angles[1] - angles[2]), math.cos(angles[1] - angles[2])))

            if diff01 < diff02 and diff01 < diff12:
                # returns the average angle between pixels 0 and 1
                return math.atan2(numpy.sum(numpy.sin([angles[0], angles[1]])),
                                  numpy.sum(numpy.cos([angles[0], angles[1]]))), diff01

            elif diff02 < diff01 and diff02 < diff12:
                # returns the average angle between pixels 0 and 2
                return math.atan2(numpy.sum(numpy.sin([angles[0], angles[2]])),
                                  numpy.sum(numpy.cos([angles[0], angles[2]]))), diff02

            else:
                # returns the average angle between pixels 1 and 2
                return math.atan2(numpy.sum(numpy.sin([angles[1], angles[2]])),
                                  numpy.sum(numpy.cos([angles[1], angles[2]]))), diff12

    # default answer: failed to compute angle
    return None


# Detects minutiae on the given <fingerprint> image, after proper enhancement.
# Observes the given <mask> to avoid detecting minutiae on improper parts of the fingerprint image.
# Provide <view> as True if you want to see the results of computations. Will ask and wait for many key presses.
# Returns a list of ridge endings followed by a list of ridge bifurcations. Each element of these lists is
# a (x, y, angle, doubt) minutiae description, where "x" and "y" define the position of the minutiae on the fingerprint,
# "angle" defines the angle of the involved ridges, in radians, and "doubt" is a measure of non-quality;
# 0 is the highest quality, meaning no doubt at all.
def _01_detect_minutiae(fingerprint, mask, view=False):
    # method outputs
    ridge_endings = []
    ridge_bifurcs = []

    # makes the fingerprint have 0s (for valleys) and 1s (for ridges)
    fingerprint = (fingerprint > 0).astype(numpy.uint8)

    # fingerprint dimensions
    h, w = fingerprint.shape

    # for each ridge pixel
    for x in range(1, w - 1):
        for y in range(1, h - 1):
            # if the current pixel is valid according to the given mask and its values is one
            if mask[y, x] > 0 and fingerprint[y, x] == 1:
                # current 3x3 block
                block = fingerprint[y - 1: y + 2, x - 1: x + 2]

                # number of ridge pixels in the neighborhood
                ridge_count = numpy.sum(block)

                # if the number of ridge pixels is bellow 3, we may have a ridge ending
                if ridge_count < 3:
                    angle = _compute_minutiae_angle(fingerprint, (x, y), is_ridge_ending=True)
                    if angle is not None:
                        ridge_endings.append((x, y, angle[0], angle[1]))

                # else, if the number of ridge pixels is above 3, we may have a bifurcation
                elif ridge_count > 3:
                    angle = _compute_minutiae_angle(fingerprint, (x, y), is_ridge_ending=False)
                    if angle is not None:
                        ridge_bifurcs.append((x, y, angle[0], angle[1]))

    # shows the detected minutiae, if it is the case
    if view:
        _draw_minutiae(fingerprint, ridge_endings, ridge_bifurcs, 'All')

    print('[INFO] Detected minutiae.')
    return ridge_endings, ridge_bifurcs


# Removes spurious minutiae detected on the given <fingerprint> image.
# Observes the given <mask> to remove minutiae on improper parts of the fingerprint.
# Minutiae are provided through the <ridge_endings> and <ridge_bifurcations> parameters.
# Each one is a list of (x, y, angle, doubt) elements, one for each minutiae, where "x" and "y"
# define the position of the minutiae on the fingerprint, "angle" defines the angle of the involved ridges,
# in radians, and "doubt" is a measure of non-quality; 0 is the highest quality, meaning no doubt at all.
# Provide <view> as True if you want to see the results of computations. Will ask and wait for many key presses.
# Returns a cleaned list of <ridge_endings> followed by a cleaned list of <ridge_bifurcations>.
def _02_remove_spurious_minutiae(fingerprint, mask, ridge_endings, ridge_bifurcations, view=False):
    # registers the minutiae that should be kept
    good_ridge_endings = [True] * len(ridge_endings)  # all ridge endings are essential in the beginning
    good_bifurcations = [True] * len(ridge_bifurcations)  # all bifurcations are essential in the beginning

    # here go the heuristics...

    # removes colliding minutiae, keeping only the ones with lowest doubt (i.e., highest quality)
    for i in range(0, len(ridge_endings) - 1):
        for j in range(i + 1, len(ridge_endings)):
            if good_ridge_endings[i] and good_ridge_endings[j]:
                if math.sqrt((ridge_endings[i][0] - ridge_endings[j][0]) ** 2 + (
                        ridge_endings[i][1] - ridge_endings[j][1]) ** 2) < 3:
                    if ridge_endings[i][3] <= ridge_endings[j][3]:
                        good_ridge_endings[j] = False
                    else:
                        good_ridge_endings[i] = False

    for i in range(0, len(ridge_bifurcations) - 1):
        for j in range(i + 1, len(ridge_bifurcations)):
            if ridge_bifurcations[i] and ridge_bifurcations[j]:
                if math.sqrt((ridge_bifurcations[i][0] - ridge_bifurcations[j][0]) ** 2 + (
                        ridge_bifurcations[i][1] - ridge_bifurcations[j][1]) ** 2) < 3:
                    if ridge_bifurcations[i][3] <= ridge_bifurcations[j][3]:
                        good_bifurcations[j] = False
                    else:
                        good_bifurcations[i] = False

    # removes minutiae that are too close to the border of the fingerprint
    for i in range(len(ridge_endings)):
        if good_ridge_endings[i]:
            m = ridge_endings[i]
            mask_patch = mask[
                         max(0, m[1] - MIN_MASK_DIST): min(m[1] + MIN_MASK_DIST, mask.shape[0]),
                         max(0, m[0] - MIN_MASK_DIST): min(m[0] + MIN_MASK_DIST, mask.shape[1])]
            if numpy.min(mask_patch) == 0:
                good_ridge_endings[i] = False

    for i in range(len(ridge_bifurcations)):
        if good_bifurcations[i]:
            m = ridge_bifurcations[i]
            mask_patch = mask[
                         max(0, m[1] - MIN_MASK_DIST): min(m[1] + MIN_MASK_DIST, mask.shape[0]),
                         max(0, m[0] - MIN_MASK_DIST): min(m[0] + MIN_MASK_DIST, mask.shape[1])]
            if numpy.min(mask_patch) == 0:
                good_bifurcations[i] = False

    # removes ending ridges that are too close to each other and have opposing angles (either small ridge or small gap)
    to_remove = []
    for i in range(0, len(ridge_endings) - 1):
        for j in range(i + 1, len(ridge_endings)):
            if good_ridge_endings[i] and good_ridge_endings[j]:
                if math.sqrt((ridge_endings[i][0] - ridge_endings[j][0]) ** 2 + (
                        ridge_endings[i][1] - ridge_endings[j][1]) ** 2) < MIN_MINUTIAE_DIST:
                    if math.fabs(math.pi - math.fabs(ridge_endings[i][2] - ridge_endings[j][2])) < OPPOSING_ANG_TOLE:
                        to_remove.append(i)
                        to_remove.append(j)

    for i in to_remove:
        good_ridge_endings[i] = False

    # filters out spurious minutiae
    ridge_endings = numpy.array(ridge_endings)[numpy.where(good_ridge_endings)]
    ridge_bifurcations = numpy.array(ridge_bifurcations)[numpy.where(good_bifurcations)]

    # shows the minutiae, if it is the case
    if view:
        _draw_minutiae(fingerprint, ridge_endings, ridge_bifurcations, 'Cleaned')

    print('[INFO] Removed bad-quality minutiae.')
    return ridge_endings, ridge_bifurcations


# Describes the given <enhanced_fingerprint> image through the detection and extraction of minutiae.
# Observes the given <mask> to avoid minutiae on improper parts of the fingerprint.
# Provide <view> as True if you want to see the results of computations. Will ask and wait for many key presses.
# Returns a list of ridge endings followed by a list of ridge bifurcations. Each element of these lists is
# a (x, y, angle, doubt) minutiae description, where "x" and "y" define the position of the minutiae on the fingerprint,
# "angle" defines the angle of the involved ridges, in radians, and "doubt" is a measure of non-quality;
# 0 is the highest quality, meaning no doubt at all.
def describe(enhanced_fingerprint, mask, view=False):
    # detects minutiae over the given fingerprint
    ridge_endings, bifurcations = _01_detect_minutiae(enhanced_fingerprint, mask, view=view)

    # removes non-essential minutiae, keeping only the "good" ones
    ridge_endings, bifurcations = _02_remove_spurious_minutiae(enhanced_fingerprint, mask, ridge_endings,
                                                               bifurcations, view=view)

    # returns the obtained minutiae
    return ridge_endings, bifurcations
