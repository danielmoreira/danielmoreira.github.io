# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2022
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Fingerprint Recognition
# 04. Module to match minutiae.
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python".

import math
import numpy
import cv2
import multiprocessing

# Configuration parameters.
# Scale variation step and range of the Hough transform used to compare two sets of minutiae.
# HOUGH_SCALE_STEP = 0.1
# HOUGH_SCALE_RANGE = numpy.arange(0.9, 1.1, HOUGH_SCALE_STEP)
HOUGH_SCALE_RANGE = [1.0]  # no changes in scale, here

# Rotation angle variation step and range of the Hough transform used to compare two sets of minutiae.
# Angles are measured in radians.
HOUGH_ROTATION_STEP = numpy.pi / 8.0
HOUGH_ROTATION_RANGE = numpy.arange(-numpy.pi / 2.0, numpy.pi / 2.0, HOUGH_ROTATION_STEP)

# Translation step and overlay rate of the Hough transform used to compare two sets of minutiae.
# Steps are measured in pixels.
HOUGH_TRANSLATION_STEP = 10
HOUGH_TRANSLATION_OVERLAY_RATE = 0.5  # 50% of starting overlay here

# Distance (in pixels) and angle (in radians) tolerance to consider two minutiae a match.
DIST_TRSH = 15
ANGLE_TRSH = numpy.pi / 9.0

# Ridge angle magnitude representation size (in pixels).
RIDGE_ANGLE_MAG = 5


# Draws the matching minutiae between the two fingerprint images <fingerprint_1> and
# <fingerprint_2>, according to the given <matches> minutiae index pairs.
# The involved minutiae are expressed by <ridge_endings_1> and <bifurcations_1>, belonging to
# <fingerprint_1>, and <ridge_endings_2> and <bifurcations_2>, belonging to <fingerprint_2>.
# No data is returned.
def _draw_matches(fingerprint_1, fingerprint_2, matches,
                  ridge_endings_1, bifurcations_1,
                  ridge_endings_2, bifurcations_2):
    # fingerprint dimensions
    h1, w1 = fingerprint_1.shape
    h2, w2 = fingerprint_2.shape

    # output_image with fingerprints side by side
    output_image = numpy.zeros((max(h1, h2), w1 + w2), dtype=numpy.uint8)
    output_image[0:h1, 0:w1] = (fingerprint_1 > 0).astype(numpy.uint8) * 255
    output_image[0:h2, w1:w1 + w2] = (fingerprint_2 > 0).astype(numpy.uint8) * 255
    output_image = cv2.cvtColor(output_image, cv2.COLOR_GRAY2BGR)

    # draws the matches
    # ridge endings
    for m in matches[0]:
        x0 = int(m[0][0])
        y0 = int(m[0][1])
        cv2.rectangle(output_image, (x0 - 1, y0 - 1), (x0 + 2, y0 + 2), (0, 0, 255), 1)
        delta_x = int(round(math.cos(m[0][2]) * RIDGE_ANGLE_MAG))
        delta_y = int(round(math.sin(m[0][2]) * RIDGE_ANGLE_MAG))
        cv2.line(output_image, (x0, y0), (x0 + delta_x, y0 + delta_y), (0, 255, 255), 1)

        x1 = int(m[1][0] + w1)
        y1 = int(m[1][1])
        cv2.rectangle(output_image, (x1 - 1, y1 - 1), (x1 + 2, y1 + 2), (0, 0, 255), 1)
        delta_x = int(round(math.cos(m[1][2]) * RIDGE_ANGLE_MAG))
        delta_y = int(round(math.sin(m[1][2]) * RIDGE_ANGLE_MAG))
        cv2.line(output_image, (x1, y1), (x1 + delta_x, y1 + delta_y), (0, 255, 255), 1)

        cv2.line(output_image, (x0, y0), (x1, y1), (0, 255, 255), 1)

    # bifurcations
    for m in matches[1]:
        x0 = int(m[0][0])
        y0 = int(m[0][1])
        cv2.rectangle(output_image, (x0 - 1, y0 - 1), (x0 + 2, y0 + 2), (0, 255, 0), 1)
        delta_x = int(round(math.cos(m[0][2]) * RIDGE_ANGLE_MAG))
        delta_y = int(round(math.sin(m[0][2]) * RIDGE_ANGLE_MAG))
        cv2.line(output_image, (x0, y0), (x0 + delta_x, y0 + delta_y), (0, 255, 255), 1)

        x1 = int(m[1][0] + w1)
        y1 = int(m[1][1])
        cv2.rectangle(output_image, (x1 - 1, y1 - 1), (x1 + 2, y1 + 2), (0, 255, 0), 1)
        delta_x = int(round(math.cos(m[1][2]) * RIDGE_ANGLE_MAG))
        delta_y = int(round(math.sin(m[1][2]) * RIDGE_ANGLE_MAG))
        cv2.line(output_image, (x1, y1), (x1 + delta_x, y1 + delta_y), (0, 255, 255), 1)

        cv2.line(output_image, (x0, y0), (x1, y1), (0, 255, 255), 1)

    # shows the resulting image
    cv2.imshow('Matches, press key.', output_image)
    cv2.waitKey(0)


# Compares the two given minutiae, returning their distance, in terms of how dissimilar they are.
def _compare(minutiae_1, minutiae_2):
    # computes the distance between the two minutiae and verify if they agree
    dist = math.sqrt((minutiae_1[0] - minutiae_2[0]) ** 2 + (minutiae_1[1] - minutiae_2[1]) ** 2)
    if dist > DIST_TRSH:
        return float('inf')

    # computes the angle difference between the two minutiae and verify if they agree
    a1 = minutiae_1[2]
    if a1 < 0.0:
        a1 = 2.0 * numpy.pi + a1

    a2 = minutiae_2[2]
    if a2 < 0.0:
        a2 = 2.0 * numpy.pi + a2

    angle_diff = abs(a1 - a2)
    if angle_diff > ANGLE_TRSH:
        return float('inf')

    # default: returns the score distance between the two minutiae
    return (dist / DIST_TRSH + angle_diff / ANGLE_TRSH) / 2.0


# Computes the matches between the given <minutiae_1_points>, <minutiae_1_angles>, <minutiae_1_types>
# elements belonging to "fingerprint 1", and the given <minutiae_2_points>, <minutiae_2_angles>,
# <minutiae_2_types> elements belonging to "fingerprint 2". Parameters <x_scale>, <y_scale>, and
# <rotation> angle express the transformations to be applied on top of the elements belonging to
# "fingerprint 2" before doing the match (Hough transform step).
# Returns a list of matches, whose elements are (i, j) pairs, with "i" defining the index of the
# matched minutiae within "fingerprint 1", and "j" defining the index of the matched minutiae
# # within "fingerprint 2".
def _compute_matches(minutiae_1_points, minutiae_1_angles, minutiae_1_types,
                     minutiae_2_points, minutiae_2_angles, minutiae_2_types,
                     x_scale, y_scale, rotation):
    # scales the second set of minutiae according to <x_scale> and <y_scale>
    scale_matrix = numpy.zeros((3, 3), dtype=numpy.float32)
    scale_matrix[0, 0] = x_scale
    scale_matrix[1, 1] = y_scale
    scale_matrix[2, 2] = 1.0
    minutiae_2_points = cv2.perspectiveTransform(numpy.float32([minutiae_2_points]), scale_matrix)[0]

    # rotates the second set of minutiae according to <rotation>
    if rotation < 0.0:
        rotation = 2.0 * numpy.pi + rotation

    sine = math.sin(rotation)
    cosine = math.cos(rotation)

    rotation_matrix = numpy.zeros((3, 3))
    rotation_matrix[0, 0] = cosine
    rotation_matrix[0, 1] = -sine
    rotation_matrix[1, 0] = sine
    rotation_matrix[1, 1] = cosine
    rotation_matrix[2, 2] = 1.0
    minutiae_2_points = cv2.perspectiveTransform(numpy.float32([minutiae_2_points]), rotation_matrix)[0]

    # updates the angles of the second set of minutiae according to the applied rotation
    minutiae_2_angles = minutiae_2_angles.copy()
    for i in range(len(minutiae_2_angles)):
        angle = minutiae_2_angles[i]
        if angle < 0.0:
            angle = 2.0 * numpy.pi + angle

        new_angle = angle + rotation
        if new_angle > numpy.pi:
            new_angle = new_angle - 2.0 * numpy.pi

        minutiae_2_angles[i] = new_angle

    # makes the sets of minutiae be as close to their respective (x,y) axes as possible
    minutiae_1_points = minutiae_1_points - [numpy.min(minutiae_1_points[:, 0]), numpy.min(minutiae_1_points[:, 1])]
    minutiae_2_points = minutiae_2_points - [numpy.max(minutiae_2_points[:, 0]), numpy.max(minutiae_2_points[:, 1])]

    # computes the variables to control minutiae translations
    minutiae_1_corner_1 = numpy.array([numpy.min(minutiae_1_points[:, 0]),
                                       numpy.min(minutiae_1_points[:, 1])], dtype=int)
    minutiae_1_corner_2 = numpy.array([numpy.max(minutiae_1_points[:, 0]),
                                       numpy.max(minutiae_1_points[:, 1])], dtype=int)

    minutiae_1_w, minutiae_1_h = minutiae_1_corner_2 - minutiae_1_corner_1
    minutiae_1_x_offset = int(round((1.0 - HOUGH_TRANSLATION_OVERLAY_RATE) * minutiae_1_w / 2.0))
    minutiae_1_y_offset = int(round((1.0 - HOUGH_TRANSLATION_OVERLAY_RATE) * minutiae_1_h / 2.0))

    minutiae_2_corner_1 = numpy.array([numpy.min(minutiae_2_points[:, 0]),
                                       numpy.min(minutiae_2_points[:, 1])], dtype=int)
    minutiae_2_corner_2 = numpy.array([numpy.max(minutiae_2_points[:, 0]),
                                       numpy.max(minutiae_2_points[:, 1])], dtype=int)

    minutiae_2_w, minutiae_2_h = minutiae_2_corner_2 - minutiae_2_corner_1
    minutiae_2_x_offset = int(round((1.0 - HOUGH_TRANSLATION_OVERLAY_RATE) * minutiae_2_w / 2.0))
    minutiae_2_y_offset = int(round((1.0 - HOUGH_TRANSLATION_OVERLAY_RATE) * minutiae_2_h / 2.0))

    start_x = minutiae_1_x_offset + minutiae_2_x_offset
    stop_x = start_x + minutiae_1_w + minutiae_2_w - minutiae_1_x_offset - minutiae_2_x_offset
    start_y = minutiae_1_y_offset + minutiae_2_y_offset
    stop_y = start_y + minutiae_1_h + minutiae_2_h - minutiae_1_y_offset - minutiae_2_y_offset

    # stores the best matches found so far
    best_matches = []

    # for each interesting translation of the second set of minutiae
    for x_translation in range(start_x, stop_x, HOUGH_TRANSLATION_STEP):
        for y_translation in range(start_y, stop_y, HOUGH_TRANSLATION_STEP):
            # applies the current translation
            minutiae_2_points_transl = minutiae_2_points + [x_translation, y_translation]

            # computes the current matches
            matches = []
            already_matched = []
            for i in range(minutiae_1_points.shape[0]):
                current_match = None
                current_match_dist = float('inf')

                for j in range(minutiae_2_points_transl.shape[0]):
                    if j not in already_matched and minutiae_1_types[i] == minutiae_2_types[j] and \
                            minutiae_2_points_transl[j][0] > 0.0 and minutiae_2_points_transl[j][1] > 0.0:
                        dist = _compare((minutiae_1_points[i][0], minutiae_1_points[i][1], minutiae_1_angles[i]),
                                        (minutiae_2_points_transl[j][0], minutiae_2_points_transl[j][1],
                                         minutiae_2_angles[j]))
                        if dist < current_match_dist:
                            current_match = j
                            current_match_dist = dist

                if current_match is not None:
                    matches.append((i, current_match))
                    already_matched.append(current_match)

            # if the number of matches is larger than the one found before,
            # registers the current matches as the best ones
            if len(best_matches) < len(matches):
                best_matches = matches

    # returns the best set of matches
    return best_matches


# Applies Hough transform to simultaneously match <ridge_endings_1> to <ridge_endings_2>, and
# <ridge_bifurcations_1> to <ridge_bifurcations_2>.
# Returns two lists of matches, one for ridge endings, and the other for ridge bifurcations.
# The elements of these lists are (minutiae_1, minutiae_2) pairs, where each minutiae is represented by
# a (x, y, angle) triple; "x" and "y" define the pixel position of the minutiae on its respective fingerprint image,
# and "angle" define the minutiae orientation in radians.
def _01_hough_transform(ridge_endings_1, ridge_bifurcations_1, ridge_endings_2, ridge_bifurcations_2):
    # data preparation for performing Hough transform
    minutiae_set_1 = numpy.concatenate((ridge_endings_1, ridge_bifurcations_1), axis=0)
    minutiae_set_2 = numpy.concatenate((ridge_endings_2, ridge_bifurcations_2), axis=0)
    if len(minutiae_set_1) == 0 or len(minutiae_set_2) == 0:
        return [], []

    minutiae_1_points = numpy.array([[minutiae_set_1[0][0], minutiae_set_1[0][1]]])
    minutiae_1_angles = [minutiae_set_1[0][2]]
    minutiae_1_types = [True] * len(ridge_endings_1) + [False] * len(ridge_bifurcations_1)
    for i in range(1, len(minutiae_set_1)):
        minutiae_1_points = numpy.append(minutiae_1_points, [[minutiae_set_1[i][0], minutiae_set_1[i][1]]], 0)
        minutiae_1_angles.append(minutiae_set_1[i][2])

    minutiae_2_points = numpy.array([[minutiae_set_2[0][0], minutiae_set_2[0][1]]])
    minutiae_2_angles = [minutiae_set_2[0][2]]
    minutiae_2_types = [True] * len(ridge_endings_2) + [False] * len(ridge_bifurcations_2)
    for i in range(1, len(minutiae_set_2)):
        minutiae_2_points = numpy.append(minutiae_2_points, [[minutiae_set_2[i][0], minutiae_set_2[i][1]]], 0)
        minutiae_2_angles.append(minutiae_set_2[i][2])

    # holds the best matches found so far
    best_matches = []
    best_config = None

    # for each Hough configuration...
    # multiprocessing in action
    pool = multiprocessing.Pool(processes=multiprocessing.cpu_count())
    pool_result = [pool.apply_async(_compute_matches,
                                    args=(minutiae_1_points, minutiae_1_angles, minutiae_1_types,
                                          minutiae_2_points, minutiae_2_angles, minutiae_2_types,
                                          x_scale, y_scale, rotation))
                   for x_scale in HOUGH_SCALE_RANGE
                   for y_scale in HOUGH_SCALE_RANGE
                   for rotation in HOUGH_ROTATION_RANGE]
    pool.close()
    results = [r.get() for r in pool_result]

    i = -1
    for x_scale in HOUGH_SCALE_RANGE:
        for y_scale in HOUGH_SCALE_RANGE:
            for rotation in HOUGH_ROTATION_RANGE:
                i = i + 1
                print('[INFO] Hough transform at', str([x_scale, y_scale, rotation]) + ':',
                      len(results[i]), 'matches.')
                if len(best_matches) < len(results[i]):
                    best_matches = results[i]
                    best_config = [x_scale, y_scale, rotation]
    # end of multiprocessing

    ## if you get a "freeze support" runtime error when running this solution, please comment the multiprocessing
    ## code block above and replace it with the following commented "for" block...
    # for x_scale in HOUGH_SCALE_RANGE:
    #     for y_scale in HOUGH_SCALE_RANGE:
    #         for rotation in HOUGH_ROTATION_RANGE:
    #             results = _compute_matches(minutiae_1_points, minutiae_1_angles, minutiae_1_types,
    #                                        minutiae_2_points, minutiae_2_angles, minutiae_2_types,
    #                                        x_scale, y_scale, rotation)
    #
    #             print('[INFO] Hough transform at', str([x_scale, y_scale, rotation]) + ':', len(results), 'matches.')
    #
    #             if len(best_matches) < len(results):
    #                 best_matches = results
    #                 best_config = [x_scale, y_scale, rotation]
    ## end of non-multiprocessing solution

    # found the best matches up here
    print('[INFO] Best Hough with:', len(best_matches), 'matches, at:', str(best_config) + '.')

    # returns the matches separated in ridge endings and bifurcations
    ridge_ending_matches = []
    bifurcation_matches = []
    for m in best_matches:
        if minutiae_1_types[m[0]]:
            ridge_ending_matches.append(((minutiae_set_1[m[0]][0], minutiae_set_1[m[0]][1], minutiae_1_angles[m[0]]),
                                         (minutiae_set_2[m[1]][0], minutiae_set_2[m[1]][1], minutiae_2_angles[m[1]])))

        else:
            bifurcation_matches.append(((minutiae_set_1[m[0]][0], minutiae_set_1[m[0]][1], minutiae_1_angles[m[0]]),
                                        (minutiae_set_2[m[1]][0], minutiae_set_2[m[1]][1], minutiae_2_angles[m[1]])))

    return ridge_ending_matches, bifurcation_matches


# Matches the given <ridge_endings_1> (belonging to <fingerprint_1> image) to the given <ridge_endings_2>
# (belonging to <fingerprint_2> image). Does the same for <ridge_bifurcations_1> and <ridge_bifurcations_2>.
# Provide <view> as True if you want to see the results of computations. Will ask and wait for many key presses.
# Returns two lists of matches, one for ridge endings, and the other for ridge bifurcations.
# The elements of these lists are (minutiae_1, minutiae_2) pairs, where each minutiae is represented by
# a (x, y, angle) triple; "x" and "y" define the pixel position of the minutiae on its respective fingerprint image,
# and "angle" define the minutiae orientation in radians.
def match(fingerprint_1, ridge_endings_1, ridge_bifurcations_1, fingerprint_2, ridge_endings_2, ridge_bifurcations_2,
          view=False):
    # performs Hough transforms to find the best set of matches
    matches = _01_hough_transform(ridge_endings_1, ridge_bifurcations_1, ridge_endings_2, ridge_bifurcations_2)

    # draws the best matches, if it is the case
    if view:
        _draw_matches(fingerprint_1, fingerprint_2, matches, ridge_endings_1, ridge_bifurcations_1,
                      ridge_endings_2, ridge_bifurcations_2)

    # returns the best matches
    return matches
