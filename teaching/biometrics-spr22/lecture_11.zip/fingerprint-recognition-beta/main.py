# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2022
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Fingerprint Recognition
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/),
# SciPy (https://www.scipy.org/) and Scikit-Image (https://scikit-image.org/docs/dev/api/skimage.html).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python";
# "pip3 install scikit-image".

import a_acquire
import b_enhance
import c_describe
import d_match

# Test script.

fingerprint_file_path_1 = 'test-data/1.bmp'
fingerprint_file_path_2 = 'test-data/2.bmp'
# fingerprint_file_path_1 = 'test-data/3.bmp'
# fingerprint_file_path_2 = 'test-data/4.bmp'

fingerprint_1 = a_acquire.acquire_from_file(fingerprint_file_path_1, view=False)
fingerprint_2 = a_acquire.acquire_from_file(fingerprint_file_path_2, view=False)

pp_fingerprint_1, en_fingerprint_1, mask_1 = b_enhance.enhance(fingerprint_1, dark_ridges=False, view=False)
pp_fingerprint_2, en_fingerprint_2, mask_2 = b_enhance.enhance(fingerprint_2, dark_ridges=False, view=False)

ridge_endings_1, bifurcations_1 = c_describe.describe(en_fingerprint_1, mask_1, view=False)
ridge_endings_2, bifurcations_2 = c_describe.describe(en_fingerprint_2, mask_2, view=False)

if len(ridge_endings_1) + len(bifurcations_1) > 0 and len(ridge_endings_2) + len(bifurcations_2) > 0:
    matches = d_match.match(en_fingerprint_1, ridge_endings_1, bifurcations_1, en_fingerprint_2, ridge_endings_2,
                            bifurcations_2, view=True)
else:
    print('No matches were found.')
