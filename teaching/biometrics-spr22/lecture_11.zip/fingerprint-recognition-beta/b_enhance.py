# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2022
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Fingerprint Recognition
# 02. Alternative module to enhance fingerprint samples, aiming at further minutiae detection.
# This module uses the solution available at https://github.com/Utkarsh-Deshmukh/Fingerprint-Enhancement-Python
# under BSD 2-Clause "Simplified" License.
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/),
# SciPy (https://www.scipy.org/) and Scikit-Image (https://scikit-image.org/docs/dev/api/skimage.html).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python==3.4.2.17";
# "pip3 install scikit-image".

import cv2
import numpy
import skimage.morphology

from third_party.ud import image_enhance

# Configuration parameters.
# Height of presented slap fingerprint image after normalization; the original aspect ratio is kept.
FINGERPRINT_HEIGHT = 352


# Preprocesses the given <fingerprint> image (numpy 2D array with uint8 pixel values).
# Provide <dark-ridges> as False if the captured image is inverted (i.e., dark background and white ridges).
# Provide <view> as True if you want to see the result of computations. Will ask and wait for key press.
# Returns the preprocessed fingerprint as a numpy 2D uint8 array.
def _preprocess(fingerprint, dark_ridges=True, view=False):
    # makes the fingerprint grayscale, if it is still colored
    if len(fingerprint.shape) > 2 and fingerprint.shape[2] > 1:  # more than one channel?
        fingerprint = cv2.cvtColor(fingerprint, cv2.COLOR_BGR2GRAY)

    # resizes the fingerprint to present a height of <output_height> pixels, keeping original aspect ratio
    aspect_ratio = float(fingerprint.shape[0]) / fingerprint.shape[1]
    width = int(round(FINGERPRINT_HEIGHT / aspect_ratio))
    fingerprint = cv2.resize(fingerprint, (width, FINGERPRINT_HEIGHT))

    # makes the fingerprint ridges dark, if it is the case
    if not dark_ridges:
        fingerprint = abs(255 - fingerprint)

    # shows the obtained fingerprint, if it is the case
    if view:
        cv2.imshow('Preprocessing, press any key.', fingerprint)
        cv2.waitKey(0)

    print('[INFO] Preprocessed fingerprint.')
    return fingerprint


# Enhances the given <fingerprint> image (numpy 2-D array with uint8 pixel values).
# Provide <dark-ridges> as False if the captured image is inverted (i.e., dark background and white ridges).
# Provide <view> as True if you want to see the results of computations. Will ask and wait for many key presses.
# Returns a triple composed of: preprocessed fingerprint, skeletonized fingerprint, and fingerprint content mask.
def enhance(fingerprint, dark_ridges=True, view=False):
    # pre-processes the fingerprint
    pp_fingerprint = _preprocess(fingerprint, dark_ridges, view=view)

    # enhances the fingerprint with the third-party solution (Gabor filters and binarization)
    en_fingerprint, mask = image_enhance.image_enhance(pp_fingerprint)
    if view:
        cv2.imshow('Binarization, press any key.', en_fingerprint)
        cv2.waitKey(0)

    # skeletonizes the fingerprint
    sk_fingerprint = skimage.morphology.skeletonize(en_fingerprint / 255).astype(numpy.uint8) * 255
    if view:
        cv2.imshow('Skeletonization, press any key.', sk_fingerprint)
        cv2.waitKey(0)

    print('[INFO] Enhanced fingerprint.')
    return pp_fingerprint, sk_fingerprint, mask
