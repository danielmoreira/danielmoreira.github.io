# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2022
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Face Recognition
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/), Astropy (https://www.astropy.org/),
# and ArcFace (https://github.com/mobilesec/arcface-tensorflowlite).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python";
# "pip3 install astropy";
# "pip3 install arcface".

import numpy
import cv2

import a_acquire
import b_enhance
import c_describe
import d_match

# Test script, webcam usage.
# Obtains faces 1 and 2 from the webcam.
# Face 1
while True:
    img1 = a_acquire.acquire_from_camera(cam_id=0, view=False)
    face1 = b_enhance.enhance(img1, view=False)

    view_image = img1.copy()
    if face1 is not None:
        view_image = numpy.zeros((max(img1.shape[0], face1.shape[0]), img1.shape[1] + face1.shape[1], 3), numpy.uint8)
        view_image[:img1.shape[0], :img1.shape[1], :] = img1[:, :, :]
        view_image[:face1.shape[0], img1.shape[1]:, :] = cv2.cvtColor(face1, cv2.COLOR_GRAY2BGR)[:, :, :]

        cv2.imshow('Detected face 1, press any key', view_image)
        key = cv2.waitKey(1)
        if key != -1:
            break

# Face 2
while True:
    img2 = a_acquire.acquire_from_camera(cam_id=0, view=False)
    face2 = b_enhance.enhance(img2, view=False)

    view_image = img2.copy()
    if face2 is not None:
        view_image = numpy.zeros((max(img2.shape[0], face2.shape[0]), img2.shape[1] + face2.shape[1], 3), numpy.uint8)
        view_image[:img2.shape[0], :img2.shape[1], :] = img2[:, :, :]
        view_image[:face2.shape[0], img2.shape[1]:, :] = cv2.cvtColor(face2, cv2.COLOR_GRAY2BGR)[:, :, :]

        cv2.imshow('Detected face 2, press any key', view_image)
        key = cv2.waitKey(1)
        if key != -1:
            break

# descriptions and matching
desc_1 = c_describe.describe(face1)
desc_2 = c_describe.describe(face2)
dist = d_match.match(desc_1, desc_2)

view_image = numpy.zeros((max(face1.shape[0], face2.shape[0]), face1.shape[1] + face2.shape[1]), numpy.uint8)
view_image[:face1.shape[0], :face1.shape[1]] = face1[:, :]
view_image[:face2.shape[0], face1.shape[1]:] = face2[:, :]
cv2.imshow('Distance: ' + str(dist), view_image)
cv2.waitKey()
