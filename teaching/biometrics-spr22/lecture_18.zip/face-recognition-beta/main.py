# University of Notre Dame
# Course CSE 40537 / 60537 - Biometrics - Spring 2022
# Instructor: Daniel Moreira (dhenriq1@nd.edu)
# Face Recognition
# Language: Python 3
# Needed libraries: NumPy (https://numpy.org/), OpenCV (https://opencv.org/),
# and ArcFace (https://github.com/mobilesec/arcface-tensorflowlite).
# Quick install (with PyPI - https://pypi.org/): execute, on command shell (each line at a time):
# "pip3 install numpy";
# "pip3 install opencv-contrib-python";
# "pip3 install arcface".

import a_acquire
import b_enhance
# import b_enhance_2
import c_describe
import d_match

# Test script.
img1 = a_acquire.acquire_from_file('data/face_1_1.jpg', view=True)
face1 = b_enhance.enhance(img1, view=True)
# face1 = b_enhance_2.enhance(img1, view=True) CNN face detector instead of classical Viola-Jones
desc_1 = c_describe.describe(face1)

img2 = a_acquire.acquire_from_file('data/face_1_2.jpg', view=True)
face2 = b_enhance.enhance(img2, view=True)
# face2 = b_enhance_2.enhance(img2, view=True) CNN face detector instead of classical Viola-Jones
desc_2 = c_describe.describe(face2)

img3 = a_acquire.acquire_from_file('data/face_2_1.jpg', view=True)
face3 = b_enhance.enhance(img3, view=True)
# face3 = b_enhance_2.enhance(img3, view=True) CNN face detector instead of classical Viola-Jones
desc_3 = c_describe.describe(face3)

img4 = a_acquire.acquire_from_file('data/face_2_2.jpg', view=True)
face4 = b_enhance.enhance(img4, view=True)
# face4 = b_enhance_2.enhance(img4, view=True) CNN face detector instead of classical Viola-Jones
desc_4 = c_describe.describe(face4)

img5 = a_acquire.acquire_from_file('data/face_3_1.jpg', view=True)
face5 = b_enhance.enhance(img5, view=True)
# face5 = b_enhance_2.enhance(img5, view=True) CNN face detector instead of classical Viola-Jones
desc_5 = c_describe.describe(face5)

img6 = a_acquire.acquire_from_file('data/face_3_2.jpg', view=True)
face6 = b_enhance.enhance(img6, view=True)
# face6 = b_enhance_2.enhance(img6, view=True) CNN face detector instead of classical Viola-Jones
desc_6 = c_describe.describe(face6)

dist_1 = d_match.match(desc_1, desc_2)
dist_2 = d_match.match(desc_3, desc_4)
dist_3 = d_match.match(desc_5, desc_6)

dist_4 = d_match.match(desc_1, desc_3)
dist_5 = d_match.match(desc_2, desc_4)
dist_6 = d_match.match(desc_1, desc_5)
dist_7 = d_match.match(desc_2, desc_6)
dist_8 = d_match.match(desc_3, desc_5)
dist_9 = d_match.match(desc_4, desc_6)
